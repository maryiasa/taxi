package com.taxiagency.domain;

public interface Entity {
    String getId();
    void setId(String b);
}

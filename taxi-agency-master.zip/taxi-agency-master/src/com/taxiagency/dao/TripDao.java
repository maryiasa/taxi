package com.taxiagency.dao;

public interface TripDao extends Dao {
}

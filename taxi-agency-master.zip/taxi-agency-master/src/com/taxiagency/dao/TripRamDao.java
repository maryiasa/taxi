package com.taxiagency.dao;

public class TripRamDao extends RamDao implements TripDao {

}

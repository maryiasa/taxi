package com.taxiagency.dao;

public class TripFileDao extends FileDao implements TripDao {

}
